NivasaOS Brand Assets

Generated package contents:
- Horizontal logo (light/dark) in SVG and PNG
- Stacked logo (light/dark) in SVG and PNG
- Standalone symbol (light/dark) in SVG and PNG
- Favicon (light/dark) in SVG and PNG
- Browser favicon PNGs in 16, 32, 48, 64, 180, 192 and 512 px
- ICO favicon files for light and dark modes
- Preview board image

Primary brand colour: #101828

Suggested usage:
- Use light-mode logos on white or very light backgrounds
- Use dark-mode logos on dark solid backgrounds
